import { useState } from "react";
import {
  BadgeCheck,
  Boxes,
  Clock,
  Headphones,
  Search,
  ShieldCheck,
  Tag,
  Smile,
} from "lucide-react";
import engine from "@/assets/part-engine.jpg";
import brake from "@/assets/part-brake.jpg";
import headlight from "@/assets/part-headlight.jpg";
import turbo from "@/assets/part-turbo.jpg";
import wheel from "@/assets/part-wheel.jpg";
import filter from "@/assets/part-filter.jpg";
import suspension from "@/assets/part-suspension.jpg";
import workshop from "@/assets/hero-workshop.jpg";
import { MagneticButton, SectionHeading } from "./ui";
import { Viewer3D } from "./BrakeDisc3D";
import { useCountUp, useReveal } from "./useReveal";

/* ---------------- About ---------------- */

const STATS = [
  { value: 10, suffix: "+", label: "Years Experience" },
  { value: 5000, suffix: "+", label: "Parts Available" },
  { value: 1000, suffix: "+", label: "Satisfied Customers" },
  { value: 100, suffix: "%", label: "Quality Assured" },
];

function Stat({ value, suffix, label, run }: { value: number; suffix: string; label: string; run: boolean }) {
  const n = useCountUp(value, run);
  return (
    <div className="border-l border-border pl-4">
      <p className="font-display text-3xl font-bold text-foreground sm:text-4xl">
        {n.toLocaleString()}
        <span className="text-primary">{suffix}</span>
      </p>
      <p className="mt-1 text-[11px] uppercase tracking-[0.22em] text-muted-foreground">{label}</p>
    </div>
  );
}

export function About() {
  const { ref, visible } = useReveal<HTMLElement>();
  return (
    <section id="about" ref={ref} className="relative overflow-hidden py-24 sm:py-32">
      <div className="absolute inset-0 carbon opacity-60" />
      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 lg:grid-cols-2 lg:px-10">
        <div className="reveal relative" data-visible={visible}>
          <div className="absolute -inset-6 rounded-full bg-primary/15 blur-[90px]" />
          <div className="relative overflow-hidden rounded-sm border border-border lux-shadow">
            <img
              src={engine}
              alt="Machined aluminium engine component"
              width={1024}
              height={1024}
              loading="lazy"
              className="aspect-square w-full object-cover [animation:floaty_10s_ease-in-out_infinite]"
            />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background/70 to-transparent" />
          </div>
          {Array.from({ length: 8 }).map((_, i) => (
            <span
              key={i}
              className="pointer-events-none absolute size-1 rounded-full bg-primary/60"
              style={{
                left: `${10 + i * 11}%`,
                bottom: "8%",
                animation: `drift ${6 + (i % 4)}s linear ${i * 0.5}s infinite`,
              }}
            />
          ))}
        </div>

        <div className="reveal" data-visible={visible} style={{ transitionDelay: "120ms" }}>
          <SectionHeading
            align="left"
            eyebrow="About MA NA DS"
            title={
              <>
                Your Trusted Auto <span className="text-primary">Spare Parts</span> Partner
              </>
            }
            sub="MA NA DS AUTO SPARE PARTS supplies genuine and high-grade replacement components for a wide range of vehicles. From engine internals and braking systems to lighting, filtration and suspension, every part we stock is selected for durability, correct fitment and long service life."
          />
          <p className="mt-6 text-sm leading-relaxed text-muted-foreground">
            We combine deep technical knowledge with competitive pricing and fast, customer-focused service — so
            workshops, fleet operators and private owners get the right part the first time.
          </p>
          <div className="mt-10 grid grid-cols-2 gap-6">
            {STATS.map((s) => (
              <Stat key={s.label} {...s} run={visible} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- Categories ---------------- */

const CATEGORIES = [
  { name: "Engine Parts", img: engine },
  { name: "Brake System", img: brake },
  { name: "Suspension Parts", img: suspension },
  { name: "Car Lights", img: headlight },
  { name: "Filters", img: filter },
  { name: "Electrical Parts", img: engine },
  { name: "Body Parts", img: wheel },
  { name: "Cooling System", img: turbo },
  { name: "Transmission Parts", img: engine },
  { name: "Alloy Wheels", img: wheel },
];

export function Categories() {
  const { ref, visible } = useReveal<HTMLElement>(0.05);
  return (
    <section id="categories" ref={ref} className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-10">
        <SectionHeading
          eyebrow="Spare Parts"
          title={
            <>
              Browse Our <span className="text-primary">Categories</span>
            </>
          }
          sub="Ten core categories covering every critical system of your vehicle, stocked and ready."
        />
        <div className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
          {CATEGORIES.map((c, i) => (
            <article
              key={c.name}
              className="reveal group relative overflow-hidden rounded-sm border border-border bg-card transition-all duration-500 hover:-translate-y-2 hover:border-primary/60 hover:red-glow"
              data-visible={visible}
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <div className="absolute inset-0 bg-gradient-to-b from-primary/0 to-primary/0 transition-all duration-500 group-hover:from-primary/10 group-hover:to-transparent" />
              <img
                src={c.img}
                alt={c.name}
                width={1024}
                height={1024}
                loading="lazy"
                className="aspect-square w-full object-cover transition-transform duration-700 group-hover:rotate-[6deg] group-hover:scale-110"
              />
              <div className="relative border-t border-border p-4">
                <h3 className="font-display text-[12px] font-semibold uppercase tracking-[0.18em] text-muted-foreground transition-colors duration-300 group-hover:text-foreground">
                  {c.name}
                </h3>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Featured products ---------------- */

const PRODUCTS = [
  {
    name: "Premium Brake Disc",
    img: brake,
    desc: "Drilled and slotted rotor with high-carbon casting for consistent stopping power under heat.",
    fits: "Toyota Land Cruiser · Nissan Patrol",
  },
  {
    name: "LED Headlight Unit",
    img: headlight,
    desc: "Full LED projector assembly with DRL signature, sealed housing and OEM plug fitment.",
    fits: "BMW 5 Series · Mercedes-Benz E-Class",
  },
  {
    name: "Performance Air Filter",
    img: filter,
    desc: "High-flow filtration element that protects the intake while restoring throttle response.",
    fits: "Honda Accord · Hyundai Sonata",
  },
  {
    name: "Turbocharger Assembly",
    img: turbo,
    desc: "Balanced turbine and compressor unit, pressure tested and ready for direct installation.",
    fits: "Ford Ranger · Kia Sorento",
  },
  {
    name: "Shock Absorber",
    img: suspension,
    desc: "Gas-charged damper engineered for load stability and controlled ride comfort.",
    fits: "Toyota Hilux · Nissan Navara",
  },
  {
    name: "Engine Cylinder Head",
    img: engine,
    desc: "Precision-machined head with pressure-checked seats and true deck surface.",
    fits: "Lexus LX · Toyota Prado",
  },
  {
    name: "Alloy Wheel",
    img: wheel,
    desc: "Flow-formed alloy with machined face finish, TÜV-grade strength and balanced weight.",
    fits: "Audi Q7 · BMW X5",
  },
  {
    name: "Oil Filter Set",
    img: filter,
    desc: "Anti-drainback filtration set maintaining clean pressure through every service interval.",
    fits: "Honda CR-V · Toyota Camry",
  },
];

export function Products() {
  const { ref, visible } = useReveal<HTMLElement>(0.05);
  return (
    <section id="products" ref={ref} className="relative overflow-hidden py-24 sm:py-32">
      <div className="absolute inset-0 bg-[var(--color-surface)]" />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-10">
        <SectionHeading
          eyebrow="Featured Products"
          title={
            <>
              The <span className="text-primary">Showroom</span>
            </>
          }
          sub="A selection of the parts our customers ask for most — each verified for fitment before it leaves the counter."
        />
        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {PRODUCTS.map((p, i) => (
            <article
              key={p.name}
              className="reveal group relative flex flex-col overflow-hidden rounded-sm border border-border bg-card transition-all duration-500 hover:-translate-y-2 hover:border-primary/60 hover:red-glow"
              data-visible={visible}
              style={{ transitionDelay: `${i * 60}ms`, transformStyle: "preserve-3d" }}
            >
              <div className="relative overflow-hidden">
                <img
                  src={p.img}
                  alt={p.name}
                  width={1024}
                  height={1024}
                  loading="lazy"
                  className="aspect-square w-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
              </div>
              <div className="flex flex-1 flex-col p-5">
                <h3 className="font-display text-sm font-bold uppercase tracking-[0.14em]">{p.name}</h3>
                <p className="mt-3 text-xs leading-relaxed text-muted-foreground">{p.desc}</p>
                <p className="mt-4 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                  Compatible with
                  <span className="mt-1 block text-primary">{p.fits}</span>
                </p>
                <div className="mt-6 flex flex-wrap gap-2">
                  <a
                    href="#explore"
                    className="rounded-sm border border-border px-3 py-2 font-display text-[10px] uppercase tracking-[0.18em] text-muted-foreground transition-colors duration-300 hover:border-primary hover:text-primary"
                  >
                    View Details
                  </a>
                  <a
                    href="#contact"
                    className="rounded-sm bg-primary px-3 py-2 font-display text-[10px] uppercase tracking-[0.18em] text-primary-foreground transition-shadow duration-300 hover:red-glow"
                  >
                    Contact for Price
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- 3D viewer ---------------- */

export function Explore3D() {
  return (
    <section id="explore" className="relative overflow-hidden py-24 sm:py-32">
      <div className="absolute left-1/2 top-1/2 size-[36rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/12 blur-[150px]" />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-10">
        <SectionHeading
          eyebrow="Interactive"
          title={
            <>
              Explore in <span className="text-primary">3D</span>
            </>
          }
          sub="Drag to rotate, scroll to zoom, and hover the markers to inspect each component of a performance braking assembly."
        />
        <div className="mt-14 h-[65vh] min-h-[420px] overflow-hidden rounded-sm border border-border glass lux-shadow">
          <Viewer3D />
        </div>
      </div>
    </section>
  );
}

/* ---------------- Brands ---------------- */

const BRANDS = [
  "Toyota",
  "Honda",
  "BMW",
  "Mercedes-Benz",
  "Audi",
  "Nissan",
  "Hyundai",
  "Kia",
  "Ford",
  "Lexus",
];

const MODELS: Record<string, string[]> = {
  Toyota: ["Land Cruiser", "Hilux", "Camry", "Prado"],
  Honda: ["Accord", "Civic", "CR-V"],
  BMW: ["3 Series", "5 Series", "X5"],
  "Mercedes-Benz": ["C-Class", "E-Class", "G-Class"],
  Audi: ["A4", "Q5", "Q7"],
  Nissan: ["Patrol", "Navara", "Altima"],
  Hyundai: ["Sonata", "Tucson", "Santa Fe"],
  Kia: ["Sportage", "Sorento", "Seltos"],
  Ford: ["Ranger", "Explorer", "F-150"],
  Lexus: ["LX", "RX", "ES"],
};

const PART_TYPES = ["Engine", "Brakes", "Suspension", "Lights", "Filters", "Electrical", "Cooling"];

export function Brands() {
  const { ref, visible } = useReveal<HTMLElement>(0.05);
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [year, setYear] = useState("");
  const [part, setPart] = useState("");
  const [result, setResult] = useState<string | null>(null);

  const select =
    "w-full rounded-sm border border-border bg-background px-4 py-3.5 font-display text-[11px] uppercase tracking-[0.18em] text-foreground outline-none transition-shadow duration-300 focus:red-glow";

  return (
    <section id="brands" ref={ref} className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-10">
        <SectionHeading
          eyebrow="Compatibility"
          title={
            <>
              Brands We <span className="text-primary">Supply</span>
            </>
          }
          sub="Parts sourced and matched for the region's most common makes."
        />
        <div className="mt-14 grid grid-cols-2 gap-px overflow-hidden rounded-sm border border-border bg-border sm:grid-cols-5">
          {BRANDS.map((b, i) => (
            <div
              key={b}
              className="reveal group flex h-24 items-center justify-center bg-card transition-colors duration-500 hover:bg-[var(--color-surface)]"
              data-visible={visible}
              style={{ transitionDelay: `${i * 40}ms` }}
            >
              <span className="font-display text-xs font-semibold uppercase tracking-[0.22em] text-muted-foreground transition-colors duration-300 group-hover:text-primary">
                {b}
              </span>
            </div>
          ))}
        </div>

        <div className="mt-16 rounded-sm border border-border glass p-6 sm:p-10">
          <h3 className="text-center font-display text-xl font-bold uppercase tracking-[0.1em] sm:text-2xl">
            Find the Right Part for Your Vehicle
          </h3>
          <form
            className="mt-8 grid gap-3 md:grid-cols-5"
            onSubmit={(e) => {
              e.preventDefault();
              setResult(
                `We'll check availability for ${[brand, model, year, part].filter(Boolean).join(" · ") || "your vehicle"} and reply on WhatsApp.`,
              );
            }}
          >
            <select
              className={select}
              value={brand}
              onChange={(e) => {
                setBrand(e.target.value);
                setModel("");
              }}
            >
              <option value="">Select Brand</option>
              {BRANDS.map((b) => (
                <option key={b}>{b}</option>
              ))}
            </select>
            <select className={select} value={model} onChange={(e) => setModel(e.target.value)}>
              <option value="">Select Model</option>
              {(MODELS[brand] ?? []).map((m) => (
                <option key={m}>{m}</option>
              ))}
            </select>
            <select className={select} value={year} onChange={(e) => setYear(e.target.value)}>
              <option value="">Select Year</option>
              {Array.from({ length: 26 }).map((_, i) => (
                <option key={i}>{2026 - i}</option>
              ))}
            </select>
            <select className={select} value={part} onChange={(e) => setPart(e.target.value)}>
              <option value="">Search Part</option>
              {PART_TYPES.map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-2 rounded-sm bg-primary px-5 py-3.5 font-display text-[11px] font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-shadow duration-300 hover:red-glow"
            >
              <Search className="size-3.5" /> Search
            </button>
          </form>
          {result ? <p className="mt-5 text-center text-xs text-primary">{result}</p> : null}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Why us ---------------- */

const REASONS = [
  { icon: ShieldCheck, title: "Genuine Quality", text: "Verified components from trusted manufacturers only." },
  { icon: Boxes, title: "Wide Range of Parts", text: "Thousands of references across every vehicle system." },
  { icon: Tag, title: "Competitive Prices", text: "Direct sourcing keeps our pricing honest and sharp." },
  { icon: Headphones, title: "Expert Assistance", text: "Technical staff who identify the exact part you need." },
  { icon: Clock, title: "Fast Response", text: "Quotes and availability confirmed within minutes." },
  { icon: Smile, title: "Customer Satisfaction", text: "Long-term relationships built on correct fitment." },
];

export function WhyUs() {
  const { ref, visible } = useReveal<HTMLElement>(0.05);
  return (
    <section id="why" ref={ref} className="relative overflow-hidden py-24 sm:py-32">
      <div className="absolute inset-0 carbon opacity-70" />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-10">
        <SectionHeading
          eyebrow="Why Choose Us"
          title={
            <>
              Built On <span className="text-primary">Trust</span>
            </>
          }
        />
        <div className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {REASONS.map((r, i) => (
            <div
              key={r.title}
              className="reveal group relative overflow-hidden rounded-sm border border-border bg-card/70 p-8 transition-all duration-500 hover:-translate-y-1.5 hover:border-primary/60 hover:red-glow"
              data-visible={visible}
              style={{ transitionDelay: `${i * 70}ms` }}
            >
              <r.icon
                className="size-7 text-primary transition-transform duration-500 group-hover:scale-110"
                strokeWidth={1.25}
              />
              <h3 className="mt-6 font-display text-sm font-bold uppercase tracking-[0.16em]">{r.title}</h3>
              <p className="mt-3 text-xs leading-relaxed text-muted-foreground">{r.text}</p>
              <span className="pointer-events-none absolute -right-10 -top-10 size-24 rounded-full bg-primary/20 opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-100" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Parallax band ---------------- */

export function ParallaxBand() {
  const { ref, visible } = useReveal<HTMLElement>(0.15);
  return (
    <section ref={ref} className="relative h-[70vh] min-h-[420px] overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-fixed bg-center"
        style={{ backgroundImage: `url(${workshop})` }}
        aria-hidden
      />
      <div className="absolute inset-0 bg-background/75" />
      <div className="relative mx-auto flex h-full max-w-4xl flex-col items-center justify-center px-5 text-center">
        <h2
          className="reveal font-display text-4xl font-black uppercase leading-[0.95] sm:text-6xl"
          data-visible={visible}
        >
          <span className="metal-text">Quality Parts.</span>
          <span className="mt-2 block text-primary">Reliable Performance.</span>
        </h2>
        <div className="reveal mt-10" data-visible={visible} style={{ transitionDelay: "150ms" }}>
          <MagneticButton href="#brands">
            <span className="inline-flex items-center gap-2">
              <BadgeCheck className="size-4" /> Find Your Part
            </span>
          </MagneticButton>
        </div>
      </div>
    </section>
  );
}
