import { useEffect, useState } from "react";
import { Menu, Moon, Phone, Sun, X } from "lucide-react";
import { useTheme } from "./theme";
import { CONTACT } from "./contactInfo";

const LINKS = [
  ["Home", "#home"],
  ["About", "#about"],
  ["Spare Parts", "#categories"],
  ["Products", "#products"],
  ["Brands", "#brands"],
  ["Why Us", "#why"],
  ["Contact", "#contact"],
] as const;

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { theme, toggle } = useTheme();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "glass lux-shadow" : "border-b border-transparent bg-transparent"
      }`}
    >
      <nav className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 lg:px-10">
        <a href="#home" className="flex items-baseline gap-2">
          <span className="font-display text-xl font-extrabold uppercase tracking-[0.25em] metal-text">
            MA NA DS
          </span>
          <span className="hidden text-[10px] uppercase tracking-[0.3em] text-primary sm:block">Auto Parts</span>
        </a>

        <ul className="hidden items-center gap-8 xl:flex">
          {LINKS.map(([label, href]) => (
            <li key={href}>
              <a
                href={href}
                className="relative font-display text-[11px] font-medium uppercase tracking-[0.2em] text-muted-foreground transition-colors duration-300 hover:text-foreground after:absolute after:-bottom-2 after:left-0 after:h-px after:w-0 after:bg-primary after:transition-all after:duration-300 hover:after:w-full"
              >
                {label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-3">
          <button
            onClick={toggle}
            aria-label="Toggle colour theme"
            className="grid size-10 place-items-center rounded-sm border border-border transition-colors duration-300 hover:border-primary hover:text-primary"
          >
            {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
          </button>
          <a
            href={`tel:${CONTACT.phoneRaw}`}
            className="hidden items-center gap-2 rounded-sm bg-primary px-5 py-3 font-display text-[11px] font-semibold uppercase tracking-[0.22em] text-primary-foreground transition-shadow duration-300 hover:red-glow sm:inline-flex"
          >
            <Phone className="size-3.5" /> Call Now
          </a>
          <button
            aria-label="Open menu"
            onClick={() => setOpen((o) => !o)}
            className="grid size-10 place-items-center rounded-sm border border-border xl:hidden"
          >
            {open ? <X className="size-4" /> : <Menu className="size-4" />}
          </button>
        </div>
      </nav>

      {open ? (
        <div className="glass border-t border-border xl:hidden">
          <ul className="mx-auto grid max-w-7xl gap-1 px-5 py-4">
            {LINKS.map(([label, href]) => (
              <li key={href}>
                <a
                  href={href}
                  onClick={() => setOpen(false)}
                  className="block py-3 font-display text-sm uppercase tracking-[0.2em] text-muted-foreground hover:text-primary"
                >
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </header>
  );
}
