export const CONTACT = {
  company: "MA NA DS AUTO SPARE PARTS",
  phoneDisplay: "+971 50 000 0000",
  phoneRaw: "+971500000000",
  whatsapp: "971500000000",
  email: "info@manadsautoparts.com",
  address: "Auto Spare Parts Market, Dubai, United Arab Emirates",
  mapsUrl: "https://maps.google.com/?q=Auto+Spare+Parts+Market+Dubai",
  hours: "Sat – Thu: 8:00 AM – 9:00 PM · Fri: 2:00 PM – 9:00 PM",
};
