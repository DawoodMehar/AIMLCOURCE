import { useEffect, useState } from "react";
import heroBg from "@/assets/hero-workshop.jpg";
import { HeroPart3D } from "./BrakeDisc3D";
import { MagneticButton } from "./ui";

export function Hero() {
  const [y, setY] = useState(0);

  useEffect(() => {
    const onScroll = () => setY(window.scrollY);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <section id="home" className="relative min-h-[100svh] overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={heroBg}
          alt="Cinematic automotive workshop with premium engine components"
          width={1920}
          height={1088}
          className="size-full scale-110 object-cover"
          style={{ transform: `translate3d(0, ${y * 0.25}px, 0) scale(1.15)` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/85 via-background/70 to-background" />
        <div className="absolute inset-0 opacity-40 carbon mix-blend-overlay" />
        <div className="absolute left-1/2 top-1/3 size-[42rem] -translate-x-1/2 rounded-full bg-primary/20 blur-[140px]" />
      </div>

      <div className="pointer-events-none absolute inset-0">
        {Array.from({ length: 14 }).map((_, i) => (
          <span
            key={i}
            className="absolute size-1 rounded-full bg-primary/70"
            style={{
              left: `${(i * 37) % 100}%`,
              top: `${55 + ((i * 13) % 40)}%`,
              animation: `drift ${7 + (i % 5)}s linear ${i * 0.7}s infinite`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 mx-auto grid min-h-[100svh] max-w-7xl items-center gap-6 px-5 pb-24 pt-28 lg:grid-cols-[1.05fr_0.95fr] lg:px-10">
        <div className="text-center lg:text-left">
          <p className="eyebrow">Established Automotive Supply</p>
          <h1 className="mt-6 font-display text-[15vw] font-black uppercase leading-[0.85] tracking-tight sm:text-[6rem] lg:text-[7rem]">
            <span className="block metal-text">MA NA DS</span>
            <span className="mt-2 block text-[5.2vw] font-bold tracking-[0.16em] text-foreground/90 sm:text-3xl lg:text-4xl">
              Auto Spare Parts
            </span>
          </h1>
          <p className="mt-7 text-xs uppercase tracking-[0.34em] text-muted-foreground sm:text-sm">
            Premium Quality • Genuine Parts • Reliable Service
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-4 lg:justify-start">
            <MagneticButton href="#categories">Explore Auto Parts</MagneticButton>
            <MagneticButton href="#contact" variant="ghost">
              Contact Us
            </MagneticButton>
          </div>
        </div>

        <div className="relative h-[52vh] min-h-[320px] overflow-hidden lg:h-[70vh]">
          <div className="absolute inset-0 [animation:floaty_9s_ease-in-out_infinite]">
            <HeroPart3D />
          </div>
        </div>
      </div>

      <a
        href="#about"
        aria-label="Scroll down"
        className="absolute bottom-7 left-1/2 z-10 flex -translate-x-1/2 flex-col items-center gap-3"
      >
        <span className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">Scroll</span>
        <span className="flex h-10 w-6 justify-center rounded-full border border-border pt-2">
          <span className="size-1.5 rounded-full bg-primary [animation:scrollDot_1.8s_ease-in-out_infinite]" />
        </span>
      </a>
    </section>
  );
}
