import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, Lightformer, OrbitControls, Html, ContactShadows } from "@react-three/drei";
import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";

function DiscModel({ spin = 0.35 }: { spin?: number }) {
  const group = useRef<THREE.Group>(null);

  const holes = useMemo(() => {
    const out: Array<[number, number, number]> = [];
    for (let ring = 0; ring < 2; ring++) {
      const r = 1.28 + ring * 0.28;
      const count = 14 + ring * 4;
      for (let i = 0; i < count; i++) {
        const a = (i / count) * Math.PI * 2 + ring * 0.2;
        out.push([Math.cos(a) * r, Math.sin(a) * r, 0]);
      }
    }
    return out;
  }, []);

  useFrame((_, delta) => {
    if (group.current) group.current.rotation.z += delta * spin;
  });

  return (
    <group ref={group}>
      {/* rotor face */}
      <mesh castShadow receiveShadow>
        <cylinderGeometry args={[1.85, 1.85, 0.16, 96]} />
        <meshStandardMaterial color="#b9bdc2" metalness={1} roughness={0.28} />
      </mesh>
      {/* outer edge ring */}
      <mesh position={[0, 0, 0]}>
        <torusGeometry args={[1.85, 0.09, 24, 120]} />
        <meshStandardMaterial color="#8b9095" metalness={1} roughness={0.4} />
      </mesh>
      {/* drilled holes */}
      {holes.map((p, i) => (
        <mesh key={i} position={p}>
          <cylinderGeometry args={[0.07, 0.07, 0.22, 16]} />
          <meshStandardMaterial color="#0d0d0f" metalness={0.6} roughness={0.9} />
        </mesh>
      ))}
      {/* hat */}
      <mesh position={[0, 0, 0.08]} castShadow>
        <cylinderGeometry args={[1.05, 1.05, 0.34, 64]} />
        <meshStandardMaterial color="#151518" metalness={0.95} roughness={0.35} />
      </mesh>
      <mesh position={[0, 0, 0.28]}>
        <cylinderGeometry args={[0.34, 0.34, 0.2, 32]} />
        <meshStandardMaterial color="#0b0b0d" metalness={0.9} roughness={0.5} />
      </mesh>
      {/* lug bolts */}
      {Array.from({ length: 5 }).map((_, i) => {
        const a = (i / 5) * Math.PI * 2;
        return (
          <mesh key={`b${i}`} position={[Math.cos(a) * 0.62, Math.sin(a) * 0.62, 0.3]}>
            <cylinderGeometry args={[0.09, 0.09, 0.2, 6]} />
            <meshStandardMaterial color="#cfd3d6" metalness={1} roughness={0.22} />
          </mesh>
        );
      })}
      {/* caliper */}
      <group position={[1.55, 0.3, 0]} rotation={[0, 0, 0.35]}>
        <mesh castShadow>
          <boxGeometry args={[0.55, 1.5, 0.72]} />
          <meshStandardMaterial color="#a5170f" metalness={0.75} roughness={0.3} />
        </mesh>
        <mesh position={[0, 0, 0]}>
          <boxGeometry args={[0.58, 0.9, 0.28]} />
          <meshStandardMaterial color="#0e0e10" metalness={0.7} roughness={0.6} />
        </mesh>
      </group>
    </group>
  );
}

function Rig({ intensity = 0.25 }: { intensity?: number }) {
  const { camera, pointer } = useThree();
  useFrame(() => {
    camera.position.x += (pointer.x * intensity * 4 - camera.position.x) * 0.04;
    camera.position.y += (pointer.y * intensity * 2.5 + 0.4 - camera.position.y) * 0.04;
    camera.lookAt(0, 0, 0);
  });
  return null;
}

function Studio() {
  return (
    <>
      <ambientLight intensity={0.35} />
      <directionalLight position={[6, 8, 6]} intensity={2.4} castShadow />
      <spotLight position={[-7, 2, 4]} intensity={60} angle={0.7} penumbra={1} color="#ff2a20" />
      <Environment resolution={256}>
        <Lightformer intensity={3} position={[0, 5, 2]} scale={[12, 8, 1]} />
        <Lightformer
          intensity={1.6}
          color="#9fb2c9"
          position={[-6, 1, 2]}
          rotation-y={Math.PI / 2}
          scale={[16, 3, 1]}
        />
        <Lightformer
          intensity={2}
          color="#ff3b30"
          position={[6, -1, 1]}
          rotation-y={-Math.PI / 2}
          scale={[14, 2, 1]}
        />
      </Environment>
    </>
  );
}

function useMounted() {
  const [m, setM] = useState(false);
  useEffect(() => setM(true), []);
  return m;
}

export function HeroPart3D() {
  const mounted = useMounted();
  if (!mounted) return null;
  return (
    <Canvas
      shadows
      dpr={[1, 1.75]}
      camera={{ position: [0, 0.4, 11], fov: 42 }}
      gl={{ antialias: true }}
    >
      <Studio />
      <group rotation={[0.25, -0.5, 0]}>
        <DiscModel />
      </group>
      <ContactShadows position={[0, -2.6, 0]} opacity={0.55} blur={3} scale={12} far={6} />
      <Rig />
    </Canvas>
  );
}

const HOTSPOTS: Array<{ pos: [number, number, number]; label: string; note: string }> = [
  { pos: [0, 1.95, 0], label: "01", note: "Vented rotor face" },
  { pos: [1.9, 0.5, 0.4], label: "02", note: "6-piston caliper" },
  { pos: [0, 0, 0.5], label: "03", note: "Alloy mounting hat" },
];

export function Viewer3D() {
  const mounted = useMounted();
  if (!mounted) return null;
  return (
    <Canvas shadows dpr={[1, 1.75]} camera={{ position: [0, 1, 7.5], fov: 40 }}>
      <Studio />
      <group rotation={[0.2, -0.3, 0]}>
        <DiscModel spin={0.12} />
        {HOTSPOTS.map((h) => (
          <Html key={h.label} position={h.pos} center distanceFactor={9}>
            <div className="group flex cursor-default items-center gap-2">
              <span className="grid size-6 place-items-center rounded-full border border-primary/70 bg-background/80 text-[10px] font-semibold text-primary backdrop-blur">
                {h.label}
              </span>
              <span className="whitespace-nowrap rounded-full border border-border bg-background/85 px-2 py-1 text-[10px] uppercase tracking-widest text-foreground opacity-0 backdrop-blur transition-opacity duration-300 group-hover:opacity-100">
                {h.note}
              </span>
            </div>
          </Html>
        ))}
      </group>
      <ContactShadows position={[0, -2.8, 0]} opacity={0.5} blur={3} scale={14} far={7} />
      <OrbitControls enablePan={false} minDistance={4.5} maxDistance={11} autoRotate={false} />
    </Canvas>
  );
}
