import { useRef, type ButtonHTMLAttributes, type ReactNode } from "react";

export function MagneticButton({
  children,
  variant = "primary",
  href,
  className = "",
  ...rest
}: {
  children: ReactNode;
  variant?: "primary" | "ghost";
  href?: string;
  className?: string;
} & ButtonHTMLAttributes<HTMLButtonElement>) {
  const ref = useRef<HTMLElement | null>(null);

  const onMove = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left - r.width / 2) * 0.18;
    const y = (e.clientY - r.top - r.height / 2) * 0.28;
    el.style.transform = `translate3d(${x}px, ${y}px, 0)`;
  };
  const onLeave = () => {
    if (ref.current) ref.current.style.transform = "translate3d(0,0,0)";
  };

  const base =
    "relative inline-flex items-center justify-center overflow-hidden rounded-sm px-8 py-4 font-display text-xs font-semibold uppercase tracking-[0.25em] transition-[box-shadow,background-color,color,transform] duration-300 will-change-transform";
  const skin =
    variant === "primary"
      ? "bg-primary text-primary-foreground hover:red-glow"
      : "glass text-foreground hover:red-glow hover:text-primary";

  const inner = (
    <>
      <span className="relative z-10">{children}</span>
      <span className="pointer-events-none absolute inset-y-0 -left-1/3 w-1/3 skew-x-12 bg-white/15 opacity-0 transition-opacity duration-300 group-hover:opacity-100 group-hover:[animation:sweep_0.9s_ease]" />
    </>
  );

  if (href) {
    return (
      <a
        ref={ref as React.RefObject<HTMLAnchorElement>}
        href={href}
        onMouseMove={onMove}
        onMouseLeave={onLeave}
        className={`group ${base} ${skin} ${className}`}
      >
        {inner}
      </a>
    );
  }

  return (
    <button
      ref={ref as React.RefObject<HTMLButtonElement>}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      className={`group ${base} ${skin} ${className}`}
      {...rest}
    >
      {inner}
    </button>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  sub,
  align = "center",
}: {
  eyebrow: string;
  title: ReactNode;
  sub?: string;
  align?: "center" | "left";
}) {
  return (
    <div className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      <p className="eyebrow">{eyebrow}</p>
      <h2 className="mt-4 text-3xl font-bold uppercase leading-[1.05] sm:text-5xl">{title}</h2>
      {sub ? <p className="mt-5 text-sm leading-relaxed text-muted-foreground sm:text-base">{sub}</p> : null}
      <span
        className={`mt-6 block h-px w-24 bg-gradient-to-r from-primary to-transparent ${
          align === "center" ? "mx-auto" : ""
        }`}
      />
    </div>
  );
}
