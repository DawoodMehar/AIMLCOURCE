import { useState } from "react";
import { Clock, Mail, MapPin, MessageCircle, Navigation, Phone } from "lucide-react";
import { CONTACT } from "./contactInfo";
import { SectionHeading } from "./ui";
import { useReveal } from "./useReveal";

const waLink = `https://wa.me/${CONTACT.whatsapp}`;

export function Contact() {
  const { ref, visible } = useReveal<HTMLElement>(0.05);
  const [sent, setSent] = useState(false);

  const field =
    "w-full rounded-sm border border-border bg-background/60 px-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground outline-none transition-shadow duration-300 focus:red-glow";

  const infos = [
    { icon: Phone, label: "Call", value: CONTACT.phoneDisplay, href: `tel:${CONTACT.phoneRaw}` },
    { icon: MessageCircle, label: "WhatsApp", value: CONTACT.phoneDisplay, href: waLink },
    { icon: Mail, label: "Email", value: CONTACT.email, href: `mailto:${CONTACT.email}` },
    { icon: MapPin, label: "Location", value: CONTACT.address, href: CONTACT.mapsUrl },
    { icon: Clock, label: "Business Hours", value: CONTACT.hours },
  ];

  return (
    <section id="contact" ref={ref} className="relative overflow-hidden py-24 sm:py-32">
      <div className="absolute inset-0 bg-[var(--color-surface)]" />
      <div className="absolute left-1/4 top-10 size-[30rem] rounded-full bg-primary/12 blur-[150px]" />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-10">
        <SectionHeading
          eyebrow="Contact"
          title={
            <>
              Get In <span className="text-primary">Touch</span>
            </>
          }
          sub="Send us the part you need with your vehicle details — we confirm availability and price fast."
        />

        <div className="mt-14 grid gap-10 lg:grid-cols-2">
          <div className="reveal" data-visible={visible}>
            <a
              href={`tel:${CONTACT.phoneRaw}`}
              className="block rounded-sm border border-primary/40 glass p-8 text-center transition-shadow duration-300 hover:red-glow"
            >
              <p className="text-[10px] uppercase tracking-[0.35em] text-muted-foreground">Contact Number</p>
              <p className="mt-3 font-display text-3xl font-bold tracking-[0.06em] text-primary sm:text-4xl">
                {CONTACT.phoneDisplay}
              </p>
            </a>

            <ul className="mt-6 grid gap-3">
              {infos.map((i) => (
                <li key={i.label}>
                  <a
                    href={i.href ?? undefined}
                    target={i.href?.startsWith("http") ? "_blank" : undefined}
                    rel="noreferrer"
                    className="flex items-start gap-4 rounded-sm border border-border bg-card/60 p-5 transition-colors duration-300 hover:border-primary/60"
                  >
                    <i.icon className="mt-0.5 size-4 shrink-0 text-primary" strokeWidth={1.4} />
                    <span>
                      <span className="block text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
                        {i.label}
                      </span>
                      <span className="mt-1 block text-sm text-foreground">{i.value}</span>
                    </span>
                  </a>
                </li>
              ))}
            </ul>

            <div className="mt-6 grid gap-3 sm:grid-cols-3">
              <a
                href={waLink}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-sm bg-primary px-4 py-4 font-display text-[11px] font-semibold uppercase tracking-[0.18em] text-primary-foreground transition-shadow duration-300 hover:red-glow"
              >
                <MessageCircle className="size-4" /> WhatsApp Us
              </a>
              <a
                href={`tel:${CONTACT.phoneRaw}`}
                className="inline-flex items-center justify-center gap-2 rounded-sm border border-border glass px-4 py-4 font-display text-[11px] font-semibold uppercase tracking-[0.18em] transition-shadow duration-300 hover:red-glow"
              >
                <Phone className="size-4" /> Call Now
              </a>
              <a
                href={CONTACT.mapsUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-sm border border-border glass px-4 py-4 font-display text-[11px] font-semibold uppercase tracking-[0.18em] transition-shadow duration-300 hover:red-glow"
              >
                <Navigation className="size-4" /> Directions
              </a>
            </div>
          </div>

          <form
            className="reveal rounded-sm border border-border glass p-6 sm:p-8"
            data-visible={visible}
            style={{ transitionDelay: "120ms" }}
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
            }}
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <input required className={field} placeholder="Full Name" />
              <input required className={field} placeholder="Phone Number" type="tel" />
              <input className={field} placeholder="Car Brand" />
              <input className={field} placeholder="Car Model" />
            </div>
            <input className={`${field} mt-3`} placeholder="Required Part" />
            <textarea className={`${field} mt-3 min-h-32 resize-none`} placeholder="Message" />
            <button
              type="submit"
              className="mt-5 w-full rounded-sm bg-primary px-6 py-4 font-display text-[11px] font-semibold uppercase tracking-[0.25em] text-primary-foreground transition-shadow duration-300 hover:red-glow"
            >
              Send Inquiry
            </button>
            {sent ? (
              <p className="mt-4 text-center text-xs text-primary">
                Thank you — your inquiry has been noted. For the fastest reply, message us on WhatsApp.
              </p>
            ) : null}
          </form>
        </div>
      </div>
    </section>
  );
}

export function StickyBar() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-50 grid grid-cols-2 gap-px border-t border-border bg-border sm:hidden">
      <a
        href={`tel:${CONTACT.phoneRaw}`}
        className="flex items-center justify-center gap-2 bg-card py-4 font-display text-[11px] font-semibold uppercase tracking-[0.2em]"
      >
        <Phone className="size-4 text-primary" /> Call
      </a>
      <a
        href={waLink}
        target="_blank"
        rel="noreferrer"
        className="flex items-center justify-center gap-2 bg-primary py-4 font-display text-[11px] font-semibold uppercase tracking-[0.2em] text-primary-foreground"
      >
        <MessageCircle className="size-4" /> WhatsApp
      </a>
    </div>
  );
}

export function Footer() {
  return (
    <footer className="relative border-t border-border bg-background pb-24 pt-16 sm:pb-16">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 lg:grid-cols-4 lg:px-10">
        <div className="lg:col-span-2">
          <p className="font-display text-2xl font-extrabold uppercase tracking-[0.2em] metal-text">
            MA NA DS
          </p>
          <p className="mt-1 font-display text-xs uppercase tracking-[0.3em] text-primary">Auto Spare Parts</p>
          <p className="mt-5 max-w-sm text-sm text-muted-foreground">Premium Quality Auto Spare Parts.</p>
          <p className="mt-4 max-w-sm text-xs leading-relaxed text-muted-foreground">{CONTACT.address}</p>
        </div>

        <div>
          <h3 className="font-display text-[11px] uppercase tracking-[0.28em] text-foreground">Quick Links</h3>
          <ul className="mt-5 grid gap-3 text-xs text-muted-foreground">
            {[
              ["Home", "#home"],
              ["About", "#about"],
              ["Spare Parts", "#categories"],
              ["Products", "#products"],
              ["Why Us", "#why"],
            ].map(([l, h]) => (
              <li key={h}>
                <a href={h} className="transition-colors hover:text-primary">
                  {l}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-display text-[11px] uppercase tracking-[0.28em] text-foreground">Contact</h3>
          <ul className="mt-5 grid gap-3 text-xs text-muted-foreground">
            <li>
              <a href={`tel:${CONTACT.phoneRaw}`} className="transition-colors hover:text-primary">
                {CONTACT.phoneDisplay}
              </a>
            </li>
            <li>
              <a href={waLink} target="_blank" rel="noreferrer" className="transition-colors hover:text-primary">
                WhatsApp
              </a>
            </li>
            <li>
              <a href={`mailto:${CONTACT.email}`} className="transition-colors hover:text-primary">
                {CONTACT.email}
              </a>
            </li>
            <li>
              <a href={CONTACT.mapsUrl} target="_blank" rel="noreferrer" className="transition-colors hover:text-primary">
                Location
              </a>
            </li>
            <li className="pt-2 text-[11px] leading-relaxed">{CONTACT.hours}</li>
          </ul>
        </div>
      </div>
      <div className="mx-auto mt-14 max-w-7xl border-t border-border px-5 pt-6 lg:px-10">
        <p className="text-center text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
          © 2026 MA NA DS AUTO SPARE PARTS. All Rights Reserved.
        </p>
      </div>
    </footer>
  );
}
