import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ThemeProvider } from "@/components/site/theme";
import { Nav } from "@/components/site/Nav";
import { Hero } from "@/components/site/Hero";
import { About, Brands, Categories, Explore3D, ParallaxBand, Products, WhyUs } from "@/components/site/Sections";
import { Contact, Footer, StickyBar } from "@/components/site/Contact";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MA NA DS Auto Spare Parts | Premium Genuine Car Parts" },
      {
        name: "description",
        content:
          "MA NA DS Auto Spare Parts supplies genuine engine, brake, suspension, lighting and filtration parts for Toyota, BMW, Nissan, Mercedes-Benz and more.",
      },
      { property: "og:title", content: "MA NA DS Auto Spare Parts | Premium Genuine Car Parts" },
      {
        property: "og:description",
        content:
          "Premium quality auto spare parts with expert fitment advice, competitive pricing and fast response.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Loader() {
  const [gone, setGone] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setGone(true), 1100);
    return () => clearTimeout(t);
  }, []);
  return (
    <div
      className={`pointer-events-none fixed inset-0 z-[100] grid place-items-center bg-background transition-opacity duration-700 ${
        gone ? "opacity-0" : "opacity-100"
      }`}
      aria-hidden
    >
      <div className="text-center">
        <p className="font-display text-lg font-extrabold uppercase tracking-[0.5em] metal-text">MA NA DS</p>
        <span className="mx-auto mt-5 block h-px w-40 overflow-hidden bg-border">
          <span className="block h-px w-1/3 bg-primary [animation:sweep_1.1s_ease-in-out_infinite]" />
        </span>
      </div>
    </div>
  );
}

function Index() {
  return (
    <ThemeProvider>
      <Loader />
      <Nav />
      <main>
        <Hero />
        <About />
        <Categories />
        <Products />
        <Explore3D />
        <Brands />
        <WhyUs />
        <ParallaxBand />
        <Contact />
      </main>
      <Footer />
      <StickyBar />
    </ThemeProvider>
  );
}
